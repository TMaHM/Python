status = input('enter: ')
class test():
        def __init__(self):
                pass
        
        def get(self, status):
                self.status = status

        def put(self,status):
                print(status)
                status = input('enter: ')
                if status == 'no':
                        self.put(status)
                

                


t = test()

t.get('ok')
t.put('no')

