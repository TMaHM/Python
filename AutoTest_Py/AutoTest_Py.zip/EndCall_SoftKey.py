import os, time
from functions import Phone_Function
import configurations as conf


# ip_A = 'localhost'
ip_A = '10.3.2.19'
ip_B = '10.3.2.22'

ext_A = '3207'
ext_B = '8724'

basename = os.path.basename(__file__)


test_loops = 1
for loop in range(test_loops):
    pf = Phone_Function(basename)
    pf.idle_state_set(ip_A)
    check_A = pf.check_status(ip_A, 'idle')
    pf.idle_state_set(ip_B)
    check_B = pf.check_status(ip_B, 'idle')
    if check_A and check_B :
        pf.dial(ip_A, ext_B)
        time.sleep(3)
        answer = pf.answer(ip_B, ip_A)
        if answer:
            endcall = pf.endcall(ip_A, ip_B)
            if endcall:
                with open(pf.log_file, 'a+', encoding='utf-8') as f:
                    f.write(pf.cur_time + pf.cur_exec_file_nosuffix + 'Test Loop ' + str(loop) + ' end success...\n')
                    f.close()
            else:
                with open(pf.log_file, 'a+', encoding='utf-8') as f:
                    f.write(pf.cur_time + pf.cur_exec_file_nosuffix + 'Test Loop ' + str(loop) + ' failed...\n')
                    f.close()




    # idle_state_set(ip_A)
    # check_status(ip_A, 'hold')
    # idle_state_set(ip_B)
    # check_status(ip_B, 'speaker')